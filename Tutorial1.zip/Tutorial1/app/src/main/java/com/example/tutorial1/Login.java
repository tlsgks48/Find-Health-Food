package com.example.tutorial1;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.tutorial1.GsonTest.Address;
import com.example.tutorial1.GsonTest.FamilyMember;
import com.example.tutorial1.GsonTest.User_Info;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Login extends AppCompatActivity {
    private EditText editEmail;
    Button button;
    Button button1;
    Button button_google;
    Button button_facebook;
    private EditText password;
    CheckBox auto_checkBox;
    ImageView imageView;
    private int i = 0;
    private boolean tt = true;

    private int a = 0;

  //  EditText idconfirm;
   // EditText pwconfirm;
    String idconfirm="";
    String pwconfirm="";
    String loginId, loginPwd, idpwd, ID, PW;
    int check=0;

    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            updateThread();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Gson gson = new Gson();

        // 중요한건 ArrayList -> Json으로 변환 한 다음, 값을 가져올떄 : Json -> ArrayList로 변환을 어떻게 해야되는가?
        Address address = new Address("Germany", "Berlin");

        List<FamilyMember> family = new ArrayList<>();
        family.add(new FamilyMember("wife",30));
        family.add(new FamilyMember("Daughter",5));

        Employee employee = new Employee("John",30,"john@gmail.com", address,family);
        String json = gson.toJson(employee);

        // "{\"first_name\":\"John\",\"age\":30,\"mail\":\"john@gmail.com\"}";

        //Json은 문자열 대신 문자열 형식임.

/*        String json = "{\"address\":{\"city\":\"New York\",\"country\":\"USA\"},\"age\":30,\"first_name\":\"John\",\"mail\":\"john@gmail.com\"}";
        Employee employee = gson.fromJson(json,Employee.class);

        // 어레이 리스트만 따로 불러오고 싶으면,
        FamilyMember[] family = gson.fromJson(json, FamilyMember[].class);

        // 어레이 리스트로 하는 방법은,
        Type familyType = new TypeToken<ArrayList<FamilyMember>>(){}.getType();
        ArrayList<FamilyMember> family = gson.fromJson(json, familyType);
        */

        editEmail = (EditText)findViewById(R.id.editEmail);
        button = (Button)findViewById(R.id.button3);
        button1 = (Button)findViewById(R.id.button4);
        password = (EditText)findViewById(R.id.editText2);
        button_google = (Button)findViewById(R.id.button_google);
        button_facebook = (Button)findViewById(R.id.button_facebook);
        auto_checkBox = (CheckBox)findViewById(R.id.login_auto_checkBox);
        imageView = (ImageView)findViewById(R.id.login_imageView);

        final SharedPreferences auto = getSharedPreferences("auto", Activity.MODE_PRIVATE);
        // 처음에는 쉐어드프리퍼런스에 아무런 정보도 없으므로 값을 저장할 키들을 생성한다.
        // getString의 첫 번째 인자는 저장될 키, 두 번째 인자는 값입니다.
        // 첨엔 값이 없으므로 키값은 원하는 것으로 하고 값을 null
        loginId = auto.getString("inputId2",null);
        loginPwd = auto.getString("inputPwd2",null);

        // 자동로그인 조건문, 자동로그인을 체크하고 로그인하면 inputId2에 ID랑 비밀번호를 저장해서, 값이 들어있으면, 자동로그인~~
        if(loginId !=null && loginPwd != null) {
            if(loginId.equals(auto.getString("inputId2",null)) && loginPwd.equals(auto.getString("inputPwd2",null))) {
                Toast.makeText(Login.this, loginId+"님 자동로그인 입니다.", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Login.this, MainActivity.class);
                idconfirm = loginId;
                intent.putExtra("email",idconfirm);
                startActivityForResult(intent, 1001);
                finish();
            }
        }

        //자동 로그인 체크부분을 체크하는지?
        auto_checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (buttonView.isChecked()) {
                    //Toast.makeText(Login.this, "자동로그인 체크", Toast.LENGTH_SHORT).show();
                    check = 1;

                }
                else {
                    //Toast.makeText(Login.this, "자동로그인 체크 해제", Toast.LENGTH_SHORT).show();
                    check = 0;
                }
            }
        });

        button_google.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences auto = getSharedPreferences("auto", Activity.MODE_PRIVATE);
                SharedPreferences.Editor editor = auto.edit();
                editor.clear();
                editor.commit();
                Toast.makeText(Login.this, "쉐어드 정보 클리어", Toast.LENGTH_SHORT).show();
            }
        });

            // 로그인 버튼 누를때.
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                        SharedPreferences auto = getSharedPreferences("auto", Activity.MODE_PRIVATE);

                        Gson gson = new Gson();



                        SharedPreferences.Editor autoLogin = auto.edit();

                        String iw = auto.getString(editEmail.getText().toString(),"");

                        // 이메일이랑 비번 친것이, 쉐어드에 저장되어 있는 ID라면 이메일이랑, 비번 체크.
                        if(iw != "") {
                            User_Info obj = gson.fromJson(iw,User_Info.class);
                            if ( editEmail.getText().toString().equals(obj.getmEmail()) && password.getText().toString().equals(obj.getmPassword())) {
                                if(check == 1) {
                                    autoLogin.putString("inputId2",obj.getmEmail());
                                    autoLogin.putString("inputPwd2",obj.getmPassword());
                                    autoLogin.commit();
                                }
                                Toast.makeText(Login.this, editEmail.getText().toString()+"님이 로그인 하였습니다.", Toast.LENGTH_SHORT).show();
                                // 다른 액티비티에서 User의 이메일을 공유하기 위해서, 이메일 만을 위한 쉐어드파일에 저장.
                                SharedPreferences user_email = getSharedPreferences("user_email", Activity.MODE_PRIVATE);
                                SharedPreferences.Editor email_user = user_email.edit();
                                email_user.putString("Login_email",obj.getmEmail());
                                email_user.commit();
                                // 저장 완료

                                Intent intent = new Intent(Login.this, MainActivity.class);
                                intent.putExtra("email",idconfirm);
                                startActivityForResult(intent, 1001);
                                finish();
                            }
                            else if (editEmail.getText().toString().equals(obj.getmEmail()) && !password.getText().toString().equals(obj.getmPassword())) {
                                Toast.makeText(Login.this, "비밀번호가 틀렸습니다. 다시 입력해주세요.", Toast.LENGTH_SHORT).show();
                                password.setText("");
                                password.requestFocus();
                            }
                        }
                        else {
                            Toast.makeText(Login.this, "회원가입된 아이디가 없습니다.", Toast.LENGTH_SHORT).show();
                            editEmail.setText("");
                            password.setText("");
                            editEmail.requestFocus();
                        }



/*                        autoLogin.putString("inputId2", editEmail.getText().toString());
                        autoLogin.putString("inputPwd2", password.getText().toString());
                        autoLogin.commit(); // 저장*/

/*                        Map<String,?> keys = auto.getAll();
                        for(Map.Entry<String,?> entry : keys.entrySet()) {
                            Log.d("map login", entry.getKey() + ": "+entry.getValue().toString());
                            idpwd = auto.getString(entry.getValue().toString(),"");
                            if(editEmail.getText().toString().equals(entry.getValue().toString())){
                                idconfirm = entry.getKey();
                                ID = entry.getValue().toString();
                                if (password.getText().toString().equals(idpwd)) {
                                    PW = idpwd;
                                }
                            }
                        }

                        if ( editEmail.getText().toString().equals(ID) && password.getText().toString().equals(PW)) {
                            if(check == 1) {
                                autoLogin.putString("inputId2",ID);
                                autoLogin.putString("inputPwd2",PW);
                                autoLogin.commit();
                            }
                            Toast.makeText(Login.this, editEmail.getText().toString()+"님이 로그인 하였습니다.", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(Login.this, MainActivity.class);
                            intent.putExtra("email",idconfirm);
                            startActivityForResult(intent, 1001);
                            finish();
                        }
                        else if (editEmail.getText().toString().equals(ID) && !password.getText().toString().equals(PW)) {
                            Toast.makeText(Login.this, "비밀번호가 틀렸습니다. 다시 입력해주세요.", Toast.LENGTH_SHORT).show();
                            password.setText("");
                            password.requestFocus();
                        }
                        else {
                            Toast.makeText(Login.this, "회원가입된 아이디가 없습니다.", Toast.LENGTH_SHORT).show();
                            editEmail.setText("");
                            password.setText("");
                            editEmail.requestFocus();
                        }*/
                }
           });




        // 로그인으로 메인화면으로 가는 로그인버튼 누를때.
      /*  button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // 이메일 입력확인
                if(editEmail.getText().toString().length() == 0) {
                    Toast.makeText(Login.this, "이메일을 입력하세요!", Toast.LENGTH_SHORT).show();
                    editEmail.requestFocus();
                    return;
                }
                // 비밀번호 입력확인
                if(password.getText().toString().length() == 0) {
                    Toast.makeText(Login.this, "비밀번호를 입력하세요!", Toast.LENGTH_SHORT).show();
                    password.requestFocus();
                    return;
                }
                if(!editEmail.getText().toString().equals(idconfirm)) {
                    Toast.makeText(Login.this, "이메일이 일치하지 않습니다.", Toast.LENGTH_SHORT).show();
                    editEmail.requestFocus();
                    return;
                }
                if(!password.getText().toString().equals(pwconfirm)) {
                    Toast.makeText(Login.this, "비밀번호가 일치하지 않습니다.", Toast.LENGTH_SHORT).show();
                    password.requestFocus();
                    return;
                }
                if(editEmail.getText().toString().equals(idconfirm) && password.getText().toString().equals(pwconfirm)) {
                    Toast.makeText(Login.this, idconfirm+"님이 로그인 하였습니다.", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Login.this,MainActivity.class);
                    intent.putExtra("email",idconfirm);
                    startActivityForResult(intent, 1001);
                }

            }
        });*/

        // 회원가입창으로 가는 회원가입 버튼 누를때.
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(),join.class);

                // SINGLE_TOP : 이미 만들어진게 있으면 그걸 쓰고, 없으면 만들어서 써라
               // startActivity(intent);

                // 동시에 사용 가능
                // intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP) | Intent.FLAG_ACTIVITY_CLEAR_TOP);

                // 인텐트를 보내면서 다음 액티비티로부터 데이터를 받기 위해 식별번호(1000)을 준다.
                intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivityForResult(intent, 1000);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        //Toast.makeText(Login.this, "Start", Toast.LENGTH_SHORT).show();
        tt = true;

        Thread myThread = new Thread(new Runnable() {
            @Override
            public void run() {
                while (tt) {
                    try {
                        handler.sendMessage(handler.obtainMessage());
                        Thread.sleep(1000);
                    } catch (Throwable t) {
                    }
                }

            }
        });
        myThread.start();
    }

    private void updateThread() {
        int mod = i % 7;

        switch (mod) {
            case 0:
                i++;
                imageView.setImageResource(R.drawable.logo);
                break;
            case 1:
                i++;
                imageView.setImageResource(R.drawable.bea);
                break;
            case 2:
                i++;
                imageView.setImageResource(R.drawable.eyefood_1);
                break;
            case 3:
                i++;
                imageView.setImageResource(R.drawable.bitamin_c);
                break;
            case 4:
                i++;
                imageView.setImageResource(R.drawable.gan);
                break;
            case 5:
                i++;
                imageView.setImageResource(R.drawable.omega3);
                break;
            case 6:
                i++;
                imageView.setImageResource(R.drawable.usangun);
                break;
        }
        // myi.setText(String.valueOf(i));
    }

    @Override
    protected void onPause() {
        super.onPause();
        tt = false;
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    // onResume() 메서드는 Activity로 돌아올 경우 꼭 실행이 되는 메서드
    // startActivityForResult() 메서드를 실행시킬 경우 Activity로 돌아올 때 onResume() 메서드와 onActivityResult() 메서드 중
    // 어떤 것이 우선순위가 있는 것인지 확인해보지 않고서는 헷갈리기 쉬운 부분.
    // startActivityForResult() 메서드가 먼저 실행되고 onResume() 메서드가 나중 실행된다!
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // setResult를 통해 받아온 요청번호, 상태, 데이터
        Log.d("RESULT", requestCode + "");
        Log.d("RESULT", resultCode + "");
        Log.d("RESULT", data + "");
        if(requestCode == 1001) {
            finish();
        }

        if(requestCode == 1000 && resultCode == RESULT_OK) {
            Toast.makeText(Login.this, "회원가입을 완료했습니다!", Toast.LENGTH_SHORT).show();
            idconfirm = data.getStringExtra("email");
            pwconfirm = data.getStringExtra("password");
        }
    }

}
