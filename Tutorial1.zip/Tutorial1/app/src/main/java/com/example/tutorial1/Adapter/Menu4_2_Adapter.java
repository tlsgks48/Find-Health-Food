package com.example.tutorial1.Adapter;

public class Menu4_2_Adapter {
}
