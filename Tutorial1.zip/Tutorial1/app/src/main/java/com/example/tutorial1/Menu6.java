package com.example.tutorial1;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class Menu6 extends AppCompatActivity {
    TextView textView1;
    TextView textView2;
    TextView textView3;
    String M6idconfirm="";

    final String TAG = getClass().getSimpleName();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu6);

        M6idconfirm = getIntent().getStringExtra("email");

        textView1 = (TextView)findViewById(R.id.Logout);
        textView2 = (TextView)findViewById(R.id.profil);
        textView3 = (TextView)findViewById(R.id.LogDistroy);

        // 로그아웃 텍뷰
        textView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 쉐어드프리펀스에 저장된 값들을 로그아웃 버튼을 누르면 삭제하기위해

                // 쉐어드프리펀스를 불러오고. 메인에서 만든 이름으로로

               //Toast.makeText(Menu6.this, M6idconfirm+"님이 로그아웃 하였습니다.", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Menu6.this,Login.class);
                startActivity(intent);
                SharedPreferences auto = getSharedPreferences("auto", Activity.MODE_PRIVATE);
                SharedPreferences.Editor editor = auto.edit();

                // editor.clear()는 auto에 들어있는 모든 정보를 기기에서 지움.
                Toast.makeText(Menu6.this, M6idconfirm+"님이 로그아웃 하였습니다.", Toast.LENGTH_SHORT).show();
                editor.remove("inputId2");
                editor.remove("inputPwd2");
                editor.commit();

            }
        });
        textView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Menu6.this,menu1_1.class);
                startActivity(intent);
            }
        });

        textView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent3 = new Intent(Menu6.this, PopupActivity.class);
                //intent3.putExtra("email",M6idconfirm);
                startActivity(intent3);
            }
        });
    }

/*    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode == RESULT_OK) {
            M6idconfirm = data.getStringExtra("email");
        }

    }*/
}
