package com.example.tutorial1.Adapter;

public class Menu4_2_Item {
    String Menu4_2Comment; // 댓글내용

    public Menu4_2_Item(String menu4_2Comment) {
        Menu4_2Comment = menu4_2Comment;
    }

    public String getMenu4_2Comment() {
        return Menu4_2Comment;
    }

    public void setMenu4_2Comment(String menu4_2Comment) {
        Menu4_2Comment = menu4_2Comment;
    }
}
