package com.example.tutorial1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

public class Menu5 extends AppCompatActivity {

    String M5idconfirm="";




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu5);

        M5idconfirm = getIntent().getStringExtra("email");

        // Toast.makeText(Menu5.this, M5idconfirm+"님의 메시지 전달", Toast.LENGTH_SHORT).show();
    }
}
