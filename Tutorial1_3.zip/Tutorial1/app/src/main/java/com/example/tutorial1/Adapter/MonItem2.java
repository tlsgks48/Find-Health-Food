package com.example.tutorial1.Adapter;

public class MonItem2 {
    int check2 = 1;
    String monMon2; // 이달
     String monName2; // 이름
     int monPhoto2; // 이미지
     String monSummary2; // 요약설명
     String monMemo2; // 관심과 댓글
    String monName2_2; // 이름2
    int monPhoto2_2; // 이미지2
    String monSummary2_2; // 요약설명2
    String monMemo2_2; // 관심과 댓글2

    public MonItem2(String monMon2,String monName2, int monPhoto2, String monSummary2, String monMemo2,String monName2_2, int monPhoto2_2, String monSummary2_2, String monMemo2_2) {
        this.monMon2 = monMon2;
        this.monName2 = monName2;
        this.monPhoto2 = monPhoto2;
        this.monSummary2 = monSummary2;
        this.monMemo2 = monMemo2;
        this.monName2_2 = monName2_2;
        this.monPhoto2_2 = monPhoto2_2;
        this.monSummary2_2 = monSummary2_2;
        this.monMemo2_2 = monMemo2_2;
    }

    public String getMonMon2() {
        return monMon2;
    }

    public String getMonName2() {
        return monName2;
    }

    public int getMonPhoto2() {
        return monPhoto2;
    }

    public String getMonSummary2() {
        return monSummary2;
    }

    public String getMonMemo2() {
        return monMemo2;
    }

    public String getMonName2_2() {
        return monName2_2;
    }

    public int getMonPhoto2_2() {
        return monPhoto2_2;
    }

    public String getMonSummary2_2() {
        return monSummary2_2;
    }

    public String getMonMemo2_2() {
        return monMemo2_2;
    }

    public void setMonMon2(String monMon2) {
        this.monMon2 = monMon2;
    }

    public void setMonName2(String monName2) {
        this.monName2 = monName2;
    }

    public void setMonPhoto2(int monPhoto2) {
        this.monPhoto2 = monPhoto2;
    }

    public void setMonSummary2(String monSummary2) {
        this.monSummary2 = monSummary2;
    }

    public void setMonMemo2(String monMemo2) {
        this.monMemo2 = monMemo2;
    }

    public void setMonName2_2(String monName2_2) {
        this.monName2_2 = monName2_2;
    }

    public void setMonPhoto2_2(int monPhoto2_2) {
        this.monPhoto2_2 = monPhoto2_2;
    }

    public void setMonSummary2_2(String monSummary2_2) {
        this.monSummary2_2 = monSummary2_2;
    }

    public void setMonMemo2_2(String monMemo2_2) {
        this.monMemo2_2 = monMemo2_2;
    }
}
