package com.example.tutorial1.Adapter;

import java.util.Set;

public class Menu5_chatroom_item {

    private String chatroom;

    public Menu5_chatroom_item(String chatroom) {
        this.chatroom = chatroom;
    }


    public String getChatroom() {
        return chatroom;
    }
}
